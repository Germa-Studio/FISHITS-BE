cek ip 
`ifconfig` or `ipconfig`
Run
`php artisan serve --host ${ip} --port 8000`